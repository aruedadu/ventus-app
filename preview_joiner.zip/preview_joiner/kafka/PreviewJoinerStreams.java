package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.kafka;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.GlobalKTable;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KeyValueMapper;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.kstream.ValueJoiner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.config.SerdesConfig;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.config.StreamsConfiguration;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.PreviewRefinedProductTopicMessage;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview.PreviewTopicMessage;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined.RefinedProductTopicMessage;

import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.util.FieldMapping.PREVIEW_TO_PREVIEW_DECAPITALIZED;
import static com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.util.FieldMapping.PREVIEW_TO_REFINED_FIELD_MAPPING;

@Component
@Slf4j
public class PreviewJoinerStreams {

	public static final String GLOBAL_STORE_PREVIEW_TOPIC = "global-store-previewjoiner-previewtopic";
	public static final String GLOBAL_STORE_REFINED_PRODUCT_TOPIC = "global-store-previewjoiner-refinedproducttopic";

	private static final String ASSET_PENDING_STATUS = "PENDING";

	private final String previewTopic;
	private final String refinedProductTopic;
	private final String previewRefinedProductTopic;
	@Autowired
	Environment environment;

	@Autowired
	public PreviewJoinerStreams(@Value("${previewjoiner.topic.previewTopic}") String previewTopic,
			@Value("${previewjoiner.topic.refinedProductTopic}") String refinedProductTopic,
			@Value("${previewjoiner.topic.previewRefinedProductTopic}") String previewRefinedProductTopic) {
		this.previewTopic = previewTopic;
		this.refinedProductTopic = refinedProductTopic;
		this.previewRefinedProductTopic = previewRefinedProductTopic;
	}


	@Autowired
	public void configureStreamsApi(
			@Qualifier(StreamsConfiguration.PREVIEW_TOPIC_STREAMS_BUILDER_BEAN_NAME) StreamsBuilder previewTopicStreamsBuilder,
			@Qualifier(StreamsConfiguration.REFINED_PRODUCT_TOPIC_STREAMS_BUILDER_BEAN_NAME) StreamsBuilder refinedProductTopicStreamsBuilder) {
		// initialize our state stores
		log.info("creating global k tables");
		GlobalKTable<String, PreviewTopicMessage> previewTopicGlobalKTable = createPreviewTopicGlobalKTable(
				previewTopicStreamsBuilder);
		GlobalKTable<String, RefinedProductTopicMessage> refinedProductTopicGlobalKTable = createRefinedProductTopicGlobalKTable(
				refinedProductTopicStreamsBuilder);

		log.info("creating streams processes");

		setupPreviewTopicTriggerProcessingPipeline(refinedProductTopicStreamsBuilder, refinedProductTopicGlobalKTable);

		setupRefinedProductTopicTriggerProcessingPipeline(previewTopicStreamsBuilder, previewTopicGlobalKTable);
	}

	private void copyModels(Object originModel, Object targetModel) {
		Map<String, Field> originFields = Arrays.stream(originModel.getClass().getDeclaredFields())
				.collect(Collectors.toMap(Field::getName, field -> field));
		List<Field> targetFields = Arrays.stream(targetModel.getClass().getDeclaredFields()).toList();

		targetFields.forEach(field -> {
			try {
				String fieldName = field.getName();
				if(originFields.containsKey(fieldName) && originFields.get(fieldName).getType().equals(field.getType())){
					Field originField = originFields.get(fieldName);
					originField.setAccessible(true);
					field.setAccessible(true);
					field.set(targetModel, originFields.get(fieldName).get(originModel));
					field.setAccessible(false);
				}
			}catch (IllegalAccessException e) {
				log.error(e.getMessage());
			}
		});
	}
	private void setPreviewFields(PreviewTopicMessage originModel, PreviewRefinedProductTopicMessage targetModel) {
		originModel.getB2BEnrichedData().getUpdatedFields()
						.forEach(updatedField -> updateFieldValue(
								originModel.getB2BEnrichedData(),
								targetModel,
								PREVIEW_TO_PREVIEW_DECAPITALIZED.get(updatedField),
								PREVIEW_TO_REFINED_FIELD_MAPPING.get(updatedField)
						));
	}

	private void updateFieldValue(Object sourceObject, Object targetObject, String previewFieldName, String targetFieldName) {

		try {
			Field source = sourceObject.getClass().getDeclaredField(previewFieldName);
			Field target = targetObject.getClass().getDeclaredField(targetFieldName);
			if(source.getType().equals(target.getType())){
				source.setAccessible(true);
				target.setAccessible(true);
				target.set(targetObject, source.get(sourceObject));
				target.setAccessible(false);
			}
		}catch (IllegalAccessException | NoSuchFieldException e) {
			log.error(e.getMessage());
		}

    }

	public void setupPreviewTopicTriggerProcessingPipeline(StreamsBuilder streamsBuilder,
			GlobalKTable<String, RefinedProductTopicMessage> refinedProductTopicGlobalKTable) {
		KStream<String, PreviewTopicMessage> previewTopicKStream = createPreviewTopicKStream(streamsBuilder);
        KStream<String, PreviewRefinedProductTopicMessage> previewTopicJoinedKStream = previewTopicKStream.leftJoin(
				refinedProductTopicGlobalKTable,
                (key, value) -> {
					int keyWithoutZeroes = Integer.parseInt(key);
					return keyWithoutZeroes+"";
                },
                (previewItem, publishItem) -> {
                    PreviewRefinedProductTopicMessage output = new PreviewRefinedProductTopicMessage();
                    if (publishItem != null) {
                        //  publish item exists - merge draft attributes
                        log.info("published item for {}", previewItem.getMaterialNumber());
                        copyModels(publishItem, output);
                    } else {
                        // no published item - just push what we have
						copyModels(previewItem, output);
                        log.info("no published item for {}", previewItem.getMaterialNumber());
                    }
					setPreviewFields(previewItem, output);
                    return output;
                });

		previewTopicJoinedKStream.peek((k, v) -> log.debug("previewTopic received data for key={}", k));

		previewTopicJoinedKStream.to(previewRefinedProductTopic,
				Produced.with(Serdes.String(), SerdesConfig.previewRefinedProductTopicOutputJsonSerde));
	}

	public void setupRefinedProductTopicTriggerProcessingPipeline(StreamsBuilder streamsBuilder,
			GlobalKTable<String, PreviewTopicMessage> previewTopicGlobalKTable) {
		log.info("Holi");
		/*KStream<String, RefinedProductTopicMessage> refinedProductTopicKStream = createRefinedProductTopicKStream(
				streamsBuilder);

		KStream<String, PreviewRefinedProductTopicMessage> refinedProductTopicJoinedKStream = refinedProductTopicKStream
				.leftJoin(previewTopicGlobalKTable,
                        (key, value) -> {
                            int length = 18;
                            char padChar = '0';
                            String formatSpecifier = "%" + length + "s";
                            return String.format(formatSpecifier, key).replace(' ', padChar);
                        },
                        (publishItem, previewItem) -> {
                            PreviewRefinedProductTopicMessage output = new PreviewRefinedProductTopicMessage();
                            if (previewItem != null) {
                                // preview item exists - merge draft attributes
                                log.info("preview item for {}", previewItem.getMaterialNumber());
                            } else {
                                // no preview item - just push what we have
                                log.info("no preview item for {}", publishItem.get_id());
                            }
                            return output;
                        });

		refinedProductTopicJoinedKStream.peek((k, v) -> log.debug("refinedProductTopic received data for key={}", k));

		refinedProductTopicJoinedKStream.to(previewRefinedProductTopic,
				Produced.with(Serdes.String(), SerdesConfig.previewRefinedProductTopicOutputJsonSerde));*/
	}

	/**
	 * Create KStream from consumer poll topic PHM_MULTI_MATERIAL_MOVEMENTS, while
	 * filtering some initial conditionals.
	 *
	 * @param streamsBuilder StreamsBuilder instance
	 * @return KStream for Material Movements incoming Kafka records
	 */
	private KStream<String, PreviewTopicMessage> createPreviewTopicKStream(StreamsBuilder streamsBuilder) {
		return streamsBuilder.stream(this.previewTopic,
				Consumed.with(Serdes.String(), SerdesConfig.previewTopicJsonSerde));
	}

	/**
	 * Create KStream from consumer poll topic PHM_MULTI_MATERIAL_MOVEMENTS, while
	 * filtering some initial conditionals.
	 *
	 * @param streamsBuilder StreamsBuilder instance
	 * @return KStream for Material Movements incoming Kafka records
	 */
	private KStream<String, RefinedProductTopicMessage> createRefinedProductTopicKStream(
			StreamsBuilder streamsBuilder) {
		return streamsBuilder.stream(this.refinedProductTopic,
				Consumed.with(Serdes.String(), SerdesConfig.refinedProductTopicJsonSerde));
	}

	/**
	 * Define the global KTable for topic1
	 *
	 * @param streamsBuilder StreamsBuilder instance
	 * @return GlobalKTable of topic1
	 */
	private GlobalKTable<String, PreviewTopicMessage> createPreviewTopicGlobalKTable(StreamsBuilder streamsBuilder) {
		return streamsBuilder.globalTable(previewTopic,
				Consumed.with(Serdes.String(), SerdesConfig.previewTopicJsonSerde),
				Materialized.as(GLOBAL_STORE_PREVIEW_TOPIC));
	}

	/**
	 * Define the global KTable for topic1
	 *
	 * @param streamsBuilder StreamsBuilder instance
	 * @return GlobalKTable of topic1
	 */
	private GlobalKTable<String, RefinedProductTopicMessage> createRefinedProductTopicGlobalKTable(
			StreamsBuilder streamsBuilder) {
		return streamsBuilder.globalTable(refinedProductTopic,
				Consumed.with(Serdes.String(), SerdesConfig.refinedProductTopicJsonSerde),
				Materialized.as(GLOBAL_STORE_REFINED_PRODUCT_TOPIC));
	}

}