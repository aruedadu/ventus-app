package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined.RefinedProductTopicMessage;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RefinedProductTopicProducer {
	
    @Value(value = "${previewjoiner.topic.refinedProductTopic}")
    private String topicName;

    @Autowired
    private KafkaTemplate<String, RefinedProductTopicMessage> kafkaTemplate;

    public void sendMessage(RefinedProductTopicMessage message) {
        kafkaTemplate.send(topicName, message.get_id(), message)
            .whenComplete((resulttopicName, ex) -> {
                if (ex == null) {
                    log.info("Message sent to topic: {}", message);
                } else {
                    log.error("Failed to send message", ex);
                }
            });
    }
}
