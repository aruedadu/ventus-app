package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview.PreviewTopicMessage;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PreviewTopicProducer {
	
    @Value(value = "${previewjoiner.topic.previewTopic}")
    private String topicName;

    @Autowired
    private KafkaTemplate<String, PreviewTopicMessage> kafkaTemplate;

    public void sendMessage(PreviewTopicMessage message) {
        kafkaTemplate.send(topicName, message.getMaterialNumber(), message)
            .whenComplete((result, ex) -> {
                if (ex == null) {
                    log.info("Message sent to topic: {}", message);
                } else {
                    log.error("Failed to send message", ex);
                }
            });
    }
}
