package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.config;

import org.apache.kafka.streams.state.RocksDBConfigSetter;
import org.rocksdb.CompactionStyle;
import org.rocksdb.CompressionType;
import org.rocksdb.Options;

import java.util.Map;

public class CustomRocksDbConfig implements RocksDBConfigSetter {

    @Override
    public void setConfig(final String storeName, final Options options, final Map<String, Object> configs) {
        options.setCompressionType(CompressionType.LZ4_COMPRESSION);
        options.setCompactionStyle(CompactionStyle.LEVEL);
    }

    @Override
    public void close(String storeName, Options options) {

    }
}
