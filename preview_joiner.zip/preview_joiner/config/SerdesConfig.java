package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.config;

import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.common.serialization.Serde;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerde;

import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview.PreviewTopicMessage;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined.RefinedProductTopicMessage;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.PreviewRefinedProductTopicMessage;


@Configuration
public class SerdesConfig {
	public static final Serde<PreviewTopicMessage> previewTopicJsonSerde = makeJsonSerde(PreviewTopicMessage.class, false);
	public static final Serde<RefinedProductTopicMessage> refinedProductTopicJsonSerde = makeJsonSerde(RefinedProductTopicMessage.class, false);
	public static final Serde<PreviewRefinedProductTopicMessage> previewRefinedProductTopicOutputJsonSerde = makeJsonSerde(PreviewRefinedProductTopicMessage.class, false);

    private static <T> Serde<T> makeJsonSerde(Class<T> clazz, boolean isKey) {
        Serde<T> serde = new JsonSerde<>();
        Map<String, Object> jsonSerdeConfig = new HashMap<>();
        jsonSerdeConfig.put(JsonDeserializer.TRUSTED_PACKAGES, "com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model");
        if (isKey) {
            jsonSerdeConfig.put(JsonDeserializer.KEY_DEFAULT_TYPE, clazz);
        } else {
            jsonSerdeConfig.put(JsonDeserializer.VALUE_DEFAULT_TYPE, clazz);
        }
        serde.configure(jsonSerdeConfig, isKey);
        return serde;
    }
}
