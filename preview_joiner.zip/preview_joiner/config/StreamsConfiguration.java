package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.config;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.StreamsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerde;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.exceptioinhandler.CustomDeserializationExceptionHandler;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview.PreviewTopicMessage;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined.RefinedProductTopicMessage;

import static org.apache.kafka.streams.StreamsConfig.STATE_DIR_CONFIG;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class StreamsConfiguration {

    @Value("${spring.kafka.streams.application-id}")
    private String applicationId;
    
    @Value(value = "${spring.kafka.bootstrap-servers}")
    private String bootstrapAddress;

    @Value(value = "${spring.application.name}")
    private String appName;
    
    @Value(value = "${spring.kafka.streams.state.dir}")
    private String stateStoreLocation;

    public static final String PREVIEW_TOPIC_STREAMS_BUILDER_BEAN_NAME = "previewTopicKafkaStreamsBuilder";
    public static final String REFINED_PRODUCT_TOPIC_STREAMS_BUILDER_BEAN_NAME = "refinedProductTopicKafkaStreamsBuilder";

    @Bean(name = PREVIEW_TOPIC_STREAMS_BUILDER_BEAN_NAME)
    public StreamsBuilderFactoryBean topic1KafkaStreamsBuilderFactoryBean(
            @Autowired KafkaProperties kafkaProperties
    ) {
        Map<String, Object> props = kafkaProperties.buildStreamsProperties(null);
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationId);
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, JsonSerde.class.getName());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, JsonSerde.class.getName());
        props.put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, CustomDeserializationExceptionHandler.class);
        props.put(StreamsConfig.ROCKSDB_CONFIG_SETTER_CLASS_CONFIG, CustomRocksDbConfig.class);
        // configure the state location to allow tests to use clean state for every run
        props.put(STATE_DIR_CONFIG, stateStoreLocation);
        return new StreamsBuilderFactoryBean(new KafkaStreamsConfiguration(props));

    }
    

    @Bean(name = REFINED_PRODUCT_TOPIC_STREAMS_BUILDER_BEAN_NAME)
    public StreamsBuilderFactoryBean topic2KafkaStreamsBuilderFactoryBean(
            @Autowired KafkaProperties kafkaProperties
    ) {
        Map<String, Object> props = kafkaProperties.buildStreamsProperties(null);
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationId+"-2");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, JsonSerde.class.getName());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, JsonSerde.class.getName());
        props.put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, CustomDeserializationExceptionHandler.class);
        props.put(StreamsConfig.ROCKSDB_CONFIG_SETTER_CLASS_CONFIG, CustomRocksDbConfig.class);
        // configure the state location to allow tests to use clean state for every run
        props.put(STATE_DIR_CONFIG, stateStoreLocation);
        return new StreamsBuilderFactoryBean(new KafkaStreamsConfiguration(props));
    }
    
    @Bean
    public ProducerFactory<String, PreviewTopicMessage> topic1ProducerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        return new DefaultKafkaProducerFactory<String, PreviewTopicMessage>(configProps);
    }

    @Bean
    public KafkaTemplate<String, PreviewTopicMessage> kafkaTopic1Template() {
        return new KafkaTemplate<>(topic1ProducerFactory());
    }
    
    @Bean
    public ProducerFactory<String, RefinedProductTopicMessage> topic2ProducerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        return new DefaultKafkaProducerFactory<String, RefinedProductTopicMessage>(configProps);
    }

    @Bean
    public KafkaTemplate<String, RefinedProductTopicMessage> kafkaTopic2Template() {
        return new KafkaTemplate<>(topic2ProducerFactory());
    }
}