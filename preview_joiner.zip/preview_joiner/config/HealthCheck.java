package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.config;

import org.apache.kafka.streams.KafkaStreams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.stereotype.Component;

@Component("kafka")
public class HealthCheck implements HealthIndicator {

	@Autowired
	@Qualifier(StreamsConfiguration.PREVIEW_TOPIC_STREAMS_BUILDER_BEAN_NAME)
	private StreamsBuilderFactoryBean previewTopicStreamsBuilderFactoryBean;

	@Autowired
	@Qualifier(StreamsConfiguration.REFINED_PRODUCT_TOPIC_STREAMS_BUILDER_BEAN_NAME)
	private StreamsBuilderFactoryBean refinedProductTopicStreamsBuilderFactoryBean;

	/**
	 * Return an indication of connection health with Confluent.
	 *
	 * @return the health
	 */
	@Override
	public Health health() {
		KafkaStreams previewTopciKafkaStreams = previewTopicStreamsBuilderFactoryBean.getKafkaStreams();
		KafkaStreams.State previewTopicKafkaStreamsState = previewTopciKafkaStreams.state();

		KafkaStreams refinedProductTopicKafkaStreams = refinedProductTopicStreamsBuilderFactoryBean.getKafkaStreams();
		KafkaStreams.State refinedProductTopicKafkaStreamsState = refinedProductTopicKafkaStreams.state();

		// ERROR, NOT_RUNNING, PENDING_SHUTDOWN,
		// TODO: add all four input topics and output topic
		if (!(previewTopicKafkaStreamsState == KafkaStreams.State.CREATED
				|| previewTopicKafkaStreamsState.isRunningOrRebalancing())) {
			return Health.down().withDetail("state", previewTopicKafkaStreamsState.name()).build();
		}
		if (!(refinedProductTopicKafkaStreamsState == KafkaStreams.State.CREATED
				|| refinedProductTopicKafkaStreamsState.isRunningOrRebalancing())) {
			return Health.down().withDetail("state", refinedProductTopicKafkaStreamsState.name()).build();
		}

		// CREATED, RUNNING or REBALANCING
		return Health.up().build();
	}
}