package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.controller;

import java.util.Map;

import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.state.QueryableStoreType;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.config.StreamsConfiguration;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.kafka.PreviewJoinerStreams;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview.PreviewTopicMessage;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined.RefinedProductTopicMessage;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.producer.PreviewTopicProducer;
import com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.producer.RefinedProductTopicProducer;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TopicRestController {

    ReadOnlyKeyValueStore<String, PreviewTopicMessage> previewTopicStore;
    QueryableStoreType<ReadOnlyKeyValueStore<String, PreviewTopicMessage>> queryableStorePreviewTopic = QueryableStoreTypes.keyValueStore();
    ReadOnlyKeyValueStore<String, RefinedProductTopicMessage> refinedProductTopicStore;
    QueryableStoreType<ReadOnlyKeyValueStore<String, RefinedProductTopicMessage>> queryableStoreRefinedProductTopic = QueryableStoreTypes.keyValueStore();

    private final PreviewTopicProducer previewTopicProducer;
    private final RefinedProductTopicProducer refinedProductTopicProducer;
    private StreamsBuilderFactoryBean previewTopicStreamsBuilderFactoryBean;
    private StreamsBuilderFactoryBean refinedProductTopicStreamsBuilderFactoryBean;

    @Autowired
    TopicRestController(PreviewTopicProducer topic1Producer, 
    		RefinedProductTopicProducer topic2Producer,
    		@Qualifier(StreamsConfiguration.PREVIEW_TOPIC_STREAMS_BUILDER_BEAN_NAME)
    		StreamsBuilderFactoryBean topic1StreamsBuilderFactoryBean,
    		@Qualifier(StreamsConfiguration.REFINED_PRODUCT_TOPIC_STREAMS_BUILDER_BEAN_NAME)
			StreamsBuilderFactoryBean topic2StreamsBuilderFactoryBean
    		){
				this.previewTopicProducer = topic1Producer;
				this.refinedProductTopicProducer = topic2Producer;
				this.previewTopicStreamsBuilderFactoryBean = topic1StreamsBuilderFactoryBean;
				this.refinedProductTopicStreamsBuilderFactoryBean = topic2StreamsBuilderFactoryBean;
    }
    
    private void initialize() {
        KafkaStreams kafkaStreams1 = previewTopicStreamsBuilderFactoryBean.getKafkaStreams();

        previewTopicStore =
                kafkaStreams1.store(StoreQueryParameters.fromNameAndType(PreviewJoinerStreams.GLOBAL_STORE_PREVIEW_TOPIC,
                		queryableStorePreviewTopic).enableStaleStores());

        KafkaStreams kafkaStreams2 = refinedProductTopicStreamsBuilderFactoryBean.getKafkaStreams();
        refinedProductTopicStore = 
                kafkaStreams2.store(StoreQueryParameters.fromNameAndType(PreviewJoinerStreams.GLOBAL_STORE_REFINED_PRODUCT_TOPIC,
                		queryableStoreRefinedProductTopic).enableStaleStores());
    }
	
	@GetMapping("/previewTopic")
	public String getTopic1Message(@RequestParam("id") String id) {
        if (previewTopicStore == null) {
            initialize();
        }
	    log.info("looking up {}", id);
	    
	    try {
            long approxNbr = previewTopicStore.approximateNumEntries();
            Object data = previewTopicStore.get(id);
            if (data == null) data = "null";
            ObjectMapper om = new ObjectMapper();
            return om.writeValueAsString(returnDataMap(id, approxNbr, data.toString()));
        } catch (Exception ex) {
            log.info("Exception while querying topic1 store. Exception={}", ex.getMessage());
            return ex.getMessage();
        }
	}
	
	@GetMapping("/refinedProductTopic")
	public String getTopic2Message(@RequestParam("id") String id) {
        if (refinedProductTopicStore == null) {
            initialize();
        }
	    log.info("looking up {}", id);
	    
	    try {
            long approxNbr = refinedProductTopicStore.approximateNumEntries();
            Object data = refinedProductTopicStore.get(id);
            if (data == null) data = "null";
            ObjectMapper om = new ObjectMapper();
            return om.writeValueAsString(returnDataMap(id, approxNbr, data.toString()));
        } catch (Exception ex) {
            log.info("Exception while querying topic2 store. Exception={}", ex.getMessage());
            return ex.getMessage();
        }
	}
	

    /**
     * Return a map of data to feedback to the user.
     */
    private Map<String, String> returnDataMap(String key, long nbrOfEntries, String data) {
        return Map.of("key", key, "number-of-entries", String.valueOf(nbrOfEntries), "data", data);
    }
	
	@PostMapping("/previewTopic")
	public void sendMessage(@RequestBody PreviewTopicMessage previewTopicMessage) {
		log.info(previewTopicMessage.toString());
        previewTopicProducer.sendMessage(previewTopicMessage);
	}
	
	@PostMapping("/refinedProductTopic")
	public void sendMessage(@RequestBody RefinedProductTopicMessage refinedProductTopicMessage) {
		log.info(refinedProductTopicMessage.toString());
        refinedProductTopicProducer.sendMessage(refinedProductTopicMessage);
	}
}
