package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class PreviewTopicMessage {

	@JsonProperty("MaterialNumber")
	private String materialNumber;

	@JsonProperty("B2BEnrichedData")
	private B2BEnrichedData b2BEnrichedData;

	@JsonProperty("ProductAssociations")
	private ProductAssociations productAssociations;

	@JsonProperty("ComplementaryProducts")
	private List<Object> complementaryProducts;

	@JsonProperty("ProductImages")
	private List<PreviewImage> productImages;

}
