package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PreviewImage {

    @JsonProperty("BynderID")
    String bynderID;

    @JsonProperty("Rank")
    String rank;

    @JsonProperty("AltText")
    String altText;

    @JsonProperty("AssetName")
    String assetName;

    @JsonProperty("AssetDescription")
    String assetDescription;

    @JsonProperty("Status")
    String status;

}
