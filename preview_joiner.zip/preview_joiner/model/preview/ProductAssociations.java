package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview;

import lombok.Data;

@Data
public class ProductAssociations {

    private String sequence;

    private String associationGroupID;
}
