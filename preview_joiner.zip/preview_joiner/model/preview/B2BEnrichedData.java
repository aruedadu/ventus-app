package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.preview;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class B2BEnrichedData{

    @JsonProperty("UpdatedFields")
    private List<String> updatedFields;

    @JsonProperty("ProductTitle")
    private String productTitle;

    @JsonProperty("GenericName")
    private String genericName;

    @JsonProperty("LongDescription")
    private String longDescription;

    @JsonProperty("Brand")
    private String brand;

    @JsonProperty("SubBrand")
    private String subBrand;

    @JsonProperty("Color")
    private List<String> color;

    @JsonProperty("Flavor")
    private List<String> flavor;

    @JsonProperty("Shape")
    private List<String> shape;

    @JsonProperty("AgeRange")
    private String ageRange;

    @JsonProperty("FeatureAndBenefits")
    private List<Object> featureAndBenefits;
}
