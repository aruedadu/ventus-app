package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.util;

import java.util.List;
import java.util.Map;

public class FieldMapping {

    //this maps the preview field names inside the updatedFields array to the output names
    public static final Map<String, String> PREVIEW_TO_REFINED_FIELD_MAPPING =
            Map.of(
                    "ProductTitle", "productName",
                    "GenericName", "productGenericName",
                    "Brand", "brandName",
                    "Color", "color",
                    "Flavor", "flavor",
                    "Shape", "shape"
            );

    //this maps the preview field names inside the updatedFields array to the preview object (using java camelcase)
    public static final Map<String, String> PREVIEW_TO_PREVIEW_DECAPITALIZED =
            Map.of(
                    "ProductTitle", "productTitle",
                    "GenericName", "genericName",
                    "Brand", "brand",
                    "Color", "color",
                    "Flavor", "flavor",
                    "Shape", "shape"
            );

}
