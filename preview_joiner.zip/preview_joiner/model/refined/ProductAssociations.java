package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined;

import lombok.Data;

@Data
public class ProductAssociations {
    String sequence;
    String associationGroupID;
}
