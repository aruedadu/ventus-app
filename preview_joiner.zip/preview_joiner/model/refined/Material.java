package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Material {
    @JsonProperty("$numberLong")
    String $numberLong;
}
