package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined;

import lombok.Data;

@Data
public class ActiveIngredient {
    String activeIngredientStrengthUOM;
    String activeIngredientStrength;
    String activeIngredientName;
}
