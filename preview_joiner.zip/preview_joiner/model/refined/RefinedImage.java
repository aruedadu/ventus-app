package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.model.refined;

import lombok.Data;

@Data
public class RefinedImage {

    String bynderID;

    String rank;

    String altText;

    String assetName;

    String assetDescription;

}
