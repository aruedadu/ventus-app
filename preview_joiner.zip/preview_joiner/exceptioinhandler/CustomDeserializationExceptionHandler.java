package com.cardinal.ecomm.nxtgen.pd.previewjoiner.preview_joiner.exceptioinhandler;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.streams.errors.DeserializationExceptionHandler;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.slf4j.MDC;
//import org.springframework.kafka.core.KafkaTemplate;

import java.util.Map;

@Slf4j
public class CustomDeserializationExceptionHandler implements DeserializationExceptionHandler {

//    private KafkaTemplate<String, String> dltProducer;
//    private String dltTopic;

    @Override
    public DeserializationHandlerResponse handle(ProcessorContext context, ConsumerRecord<byte[], byte[]> record, Exception exception) {
        try {
//            EdaLoggerUtils.setConsumerRecordContext(record);
//            dltProducer.send(new ProducerRecord<>(dltTopic, new String(record.key()), new String(record.value())));
//            log.error("Exception was caught during deserialization. " + EdaEvents.CONSUMER.WRITE_TO_DLT_SUCCESS(dltTopic, exception));
        	log.error("Exception was caught during deserialization.", exception);
        } catch (Exception ex) {
//            log.error("Exception was caught during deserialization. " + EdaEvents.CONSUMER.WRITE_TO_DLT_ERROR(dltTopic, exception.getMessage(), ex.getMessage()));
        } finally {
            MDC.clear();
        }
        return DeserializationHandlerResponse.CONTINUE;
    }

    @Override
    public void configure(Map<String, ?> configs) {
  //      dltProducer = (KafkaTemplate<String, String>) configs.get("dltProducer");
  //      dltTopic = configs.get("dltTopic").toString();
    }
}